var app = app ||{};

$(function( $ ) {

	var Place = Backbone.Model.extend({
		defaults: {
		  name: '',
		  description: '', 
		  address: '',
		  rating: 3,
		  distance: '??'
		}
	});
	  
	var PlaceList =  Backbone.Collection.extend({
		model : Place
	});

	app.Places = new PlaceList();
	
	// Represents a place
	app.PlaceView = Backbone.View.extend({

		//... is a list tag.
		tagName:  'li',

		// Cache the template function for a single item.
		template: _.template( $('#place-template').html() ),

		// The DOM events specific to an item.
		events: {
			'dblclick label': 'edit',
			'keypress .edit': 'updateOnEnter',
			'blur .edit':   'close'
		},

		initialize: function() {
			this.model.on( 'change', this.render, this );
		},

		// Re-render the titles of the todo item.
		render: function() {
			this.$el.html( this.template( this.model.toJSON() ) );
			this.form = this.$('.edit');
			return this;
		},

		// Switch this view into `"editing"` mode, displaying the input field.
		edit: function() {
			this.$el.addClass('editing');
			this.form.focus();
		},

		// Close the `"editing"` mode, saving changes to the todo.
		close: function() {
		
			var titleValue = this.$("#edit-title").val().trim();
			var descriptionValue = this.$("#edit-description").val().trim();
			var ratingValue = this.$("#edit-rating").val().trim();
			var addressValue = this.$("#edit-address").val().trim();
			
			this.model.save({ title: titleValue, description: descriptionValue, rating: ratingValue, address: addressValue });
			
			this.$el.removeClass('editing');
		},

		// If you hit `enter`, we're through editing the item.
		updateOnEnter: function( e ) {
			if ( e.which === ENTER_KEY ) {
				this.close();
			}
		}
		
	});
	
	app.SearchView = Backbone.View.extend({

		// Cache the template function for a single item.
		searchTemplate: _.template( $('#search-template').html()),
		
		events: {
			'submit': 'performSearch'
		},

		render: function() {
			
			this.$el.html( this.searchTemplate( ) );
			
			return this;
		},
		
		performSearch: function(){
			var location = $("#locationfilter").val().trim();
			app.AppView.getPlaces(location);
		}
		
	});
	  
	app.AppView = Backbone.View.extend({

		el: '#whatwewannaeapp',
		
		menuTemplate: _.template( $('#menu-template').html() ),
		
		initialize: function() {
			this.form = this.$('#event-info');		
			this.$footer = this.$('#footer');
			this.$main = this.$('#main');
			
			window.app.Places.on( 'add', this.addOne, this );
			window.app.Places.on( 'reset', this.addAll, this );
			window.app.Places.on( 'all', this.render, this );
			
			
			this.search();
		}, 
		
		render: function() {
		  
			if ( app.Places.length ) {
				this.$main.show();
				this.$footer.show();

				this.$footer.html(this.menuTemplate());
			
				 this.$('#filters li a')
					.removeClass('selected')
					.filter('[href="#/' + ( app.PlaceFilter || '' ) + '"]')
					.addClass('selected');
		 
			} else {
				this.$main.hide();
				this.$footer.hide();
			}
		},
		
		addOne: function( place ) {
			var view = new app.PlaceView({ model: place });
			$('#places-list').append( view.render().el );
		},

		addAll: function() {
			this.$('#places-list').html('');
			app.Places.each(this.addOne, this);
		},
		
		newAttributes: function() {
			return {
				title: $("#title").val().trim(),
				description: $("#description").val().trim(),
				address: $("#address").val().trim(),
				rating: $("#rating").val().trim()
			};
		},
		
		createOnEnter: function( e ) {
			app.Places.create( this.newAttributes() );
			this.form.reset();
		},
		
		search: function(){
			var view = new app.SearchView();
			$('#main').append( view.render().el );
		},
		
		getPlaces: function(location){
			app.Places.url = '/api/index.php/note.json/filter/locationfilter='+location;
			app.Places.fetch();
		}
		
	});

});