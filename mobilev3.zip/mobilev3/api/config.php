<?php
define('DB_SERVER', 'mysql:host=adminwww.db.7946997.hostedresource.com;dbname=adminwww');
define('DB_USER', 'adminwww');
define('DB_PASSWORD', 'Sabine2010');